<footer>
  <div class="footer">
  <p class="footer-content"> All Rights Reserved - Copyright &copy; 2020 <span class="tm-current-year"></span></p>
  
</div>
</footer>
</body>
</html>
